import sys
import logging
sys.path.insert(0, sys.path[0] + '/../src')

logging.basicConfig(level=logging.INFO)