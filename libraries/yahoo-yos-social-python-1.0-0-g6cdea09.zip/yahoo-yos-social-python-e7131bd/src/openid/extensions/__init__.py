"""OpenID Extension modules."""

__all__ = ['ax', 'pape', 'sreg']

from openid.extensions.draft import pape5 as pape
