# views.py

from django.http import HttpResponse

def main(request):

  result = "demo .........................................................."

  return HttpResponse(result)
