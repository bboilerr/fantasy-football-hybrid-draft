# models.py

from django.db import models

from google.appengine.ext import db
